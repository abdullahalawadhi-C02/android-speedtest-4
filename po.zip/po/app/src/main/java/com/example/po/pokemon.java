package com.example.po;

public class pokemon {
    String name;
    int image;
    int attack;
    int defence;
    private int toal;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public int getAttack() {
        return attack;
    }

    public void setAttack(int attack) {
        this.attack = attack;
    }

    public int getDefence() {
        return defence;
    }

    public void setDefence(int defence) {
        this.defence = defence;
    }

    public int getToal() {
        return toal;
    }

    public void setToal(int toal) {
        this.toal = toal;
    }
}